function [X, R, T_total] = forward_kinematics_func(q1, q2, q3, q4, q5, q6)
% Forward kinematics of the KUKA KR6/KR10 R900-2 (6 joints), built from the
% exact frame chain of the Simscape model (KR6_KR10_R900_2.slx + DataFile.m).
%   Input : q1..q6 in DEGREES (same values you feed the Constant blocks, in deg)
%   Output: X       = [x; y; z] end-effector position in mm (World frame)
%           R       = 3x3 rotation matrix of the end effector (World frame)
%           T_total = 4x4 homogeneous transformation matrix = [R X; 0 0 0 1]
% The end effector is the frame measured by the Transform Sensor in the model
% (joint-6 frame after "Rigid Transform10").
%
% Checks against Simscape (inputs in rad -> deg here):
%   q = [0 0 0 0 0 0]        -> X = [0 0 1347.5] mm
%   q = [45 45 45 45 45 45]  -> X = [517.42 568.69 660.48] mm  (Simscape: 0.5174 0.5687 0.6605 m)
%
% zero_pose_is_identity = false -> R is exactly what Simscape's sensor frame has
% zero_pose_is_identity = true  -> R is re-defined so R = I at q = 0

zero_pose_is_identity = false;

if nargin < 6
    disp('Enter joint angles in DEGREES:');
    q1 = input('q1 = ');
    q2 = input('q2 = ');
    q3 = input('q3 = ');
    q4 = input('q4 = ');
    q5 = input('q5 = ');
    q6 = input('q6 = ');
end

q = [q1 q2 q3 q4 q5 q6] * pi/180;     % degrees -> radians

T_total = chain(q);
if zero_pose_is_identity
    T0 = chain(zeros(1,6));
    T_total(1:3,1:3) = T_total(1:3,1:3) * T0(1:3,1:3).';
end
R = T_total(1:3,1:3);
X = T_total(1:3,4);

if nargout == 0
    fprintf('\nTransformation Matrix T (World -> end effector):\n');
    disp(T_total);
    fprintf('Rotation Matrix R:\n');
    disp(R);
    fprintf('End-Effector Position (mm):\n');
    fprintf('X = %.3f\nY = %.3f\nZ = %.3f\n', X);
    clear X R T_total
end
end

% ------------------------------------------------------------------
function T = chain(q)
% Frame chain of the Simscape model, in the same order as the blocks.
% q = [q1 ... q6] in RADIANS. Lengths in mm (model data is in inches * 25.4).
    s = 0.57735026918962584;           % 1/sqrt(3)
    a = 2.0943951023931953;            % 120 deg (all CAD frame rotations)

    % Frames from the DataFile (RigidTransform(k)): translation [in], angle, axis
    B1  = rtf([0.98425196850393726  5.6652059043882836  15.748031496062993], a, [ s -s  s]); % a1 -> a2 (base side)
    F1  = rtf([0.9842519685040052   5.6652059043882934  15.74803149606314 ], a, [ s -s  s]); % a1 -> a2 (follower side)
    B2  = rtf([0.98425196850393681  2.2244094488188995  33.661417322834652], a, [-s -s -s]); % a2 -> a3
    F2  = rtf([0.9842519685039619   2.2244094488188999  33.661417322835042], a, [-s -s -s]);
    B3  = rtf([9.4488188976377927   0                   34.645669291338578], a, [-s -s  s]); % a3 -> a4
    F3  = rtf([9.4488188976376986   0                   34.645669291338962], a, [-s -s  s]);
    B4  = rtf([17.519685039370085   1.7125984251968585  34.645669291338585], a, [-s -s -s]); % a4 -> a5
    F4  = rtf([17.519685039370323   1.7125984251969015  34.645669291338642], a, [-s -s -s]);
    B5  = rtf([20.374015748031489   0                   34.645669291338585], a, [-s -s  s]); % a5 -> a6
    F5  = rtf([20.374015748031447   0                   34.645669291339082], a, [-s -s  s]);

    % Rotation-only Rigid Transforms added in the model (follower-axes sequences, degrees)
    U0  = rsq('ZXY', [  90    0    0]);   % Rigid Transform   (before joint 1)
    U1  = rsq('ZXY', [  90    0    0]);   % Rigid Transform1  (after  joint 1)
    U3  = rsq('ZXZ', [  90    0  180]);   % Rigid Transform3  (before joint 2)
    U2  = rsq('ZXY', [  90    0    0]);   % Rigid Transform2  (after  joint 2)
    U5  = rsq('ZYZ', [ -90  180  180]);   % Rigid Transform5  (before joint 3)
    U4  = rsq('ZYZ', [ -90  180    0]);   % Rigid Transform4  (after  joint 3)
    U6  = rsq('XZX', [ 180  -90    0]);   % Rigid Transform6  (before joint 4)
    U7  = rsq('XZX', [ 180  -90    0]);   % Rigid Transform7  (after  joint 4)
    U8  = rsq('XZX', [ 180  180    0]);   % Rigid Transform8  (before joint 5)
    U9  = rsq('XZX', [ 180  180    0]);   % Rigid Transform9  (after  joint 5)
    U11 = rsq('XZX', [ 180  -90    0]);   % Rigid Transform11 (before joint 6)
    U10 = rsq('XZX', [ 180  -90    0]);   % Rigid Transform10 (after  joint 6 = sensor frame)

    % Joint 3 has a -pi/2 offset in the model (Constant2 = -pi/2 added to q3)
    qj = [q(1), q(2), q(3) - pi/2, q(4), q(5), q(6)];

    T = eye(4);                                              % World / base (identity)
    T = T * U0  * rz(qj(1)) * U1;                            % joint 1  (base -> a1)
    T = T * B1;                                              % a1 part: left frame is identity, right frame B1
    T = T * U3  * rz(qj(2)) * U2;                            % joint 2  (a1 -> a2)
    T = T * (F1 \ B2);                                       % a2 part: left F1, right B2
    T = T * U5  * rz(qj(3)) * U4;                            % joint 3  (a2 -> a3)
    T = T * (F2 \ B3);                                       % a3 part
    T = T * U6  * rz(qj(4)) * U7;                            % joint 4  (a3 -> a4)
    T = T * (F3 \ B4);                                       % a4 part
    T = T * U8  * rz(qj(5)) * U9;                            % joint 5  (a4 -> a5)
    T = T * (F4 \ B5);                                       % a5 part
    T = T * U11 * rz(qj(6)) * U10;                           % joint 6  (a5 -> a6), sensor frame
end

function T = rtf(t_in, ang, ax)
% Rigid transform: translation in inches (converted to mm), rotation angle-axis.
    ax = ax(:) / norm(ax);
    K  = [0 -ax(3) ax(2); ax(3) 0 -ax(1); -ax(2) ax(1) 0];
    T  = eye(4);
    T(1:3,1:3) = eye(3) + sin(ang)*K + (1 - cos(ang))*(K*K);
    T(1:3,4)   = t_in(:) * 25.4;
end

function T = rz(a)
% Revolute joint: rotation about the joint z axis
    T = eye(4);
    T(1:3,1:3) = [cos(a) -sin(a) 0; sin(a) cos(a) 0; 0 0 1];
end

function T = rsq(order, ang_deg)
% Rotation sequence about the follower (current) axes, e.g. 'ZXY', [90 0 0]
    R = eye(3);
    for k = 1:3
        a = ang_deg(k) * pi/180;
        c = cos(a);  s = sin(a);
        switch order(k)
            case 'X', Rk = [1 0 0; 0 c -s; 0 s c];
            case 'Y', Rk = [c 0 s; 0 1 0; -s 0 c];
            case 'Z', Rk = [c -s 0; s c 0; 0 0 1];
        end
        R = R * Rk;
    end
    T = eye(4);
    T(1:3,1:3) = R;
end
