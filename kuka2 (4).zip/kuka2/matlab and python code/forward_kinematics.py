"""
Forward kinematics of the KUKA KR6/KR10 R900-2 (6 joints), built from the exact
frame chain of the Simscape model (KR6_KR10_R900_2.slx + DataFile.m).

Input : q1..q6 in DEGREES
Output: X       = [x, y, z] end-effector position in mm (World frame)
        R       = 3x3 rotation matrix of the end effector (World frame)
        T_total = 4x4 homogeneous transformation matrix = [R X; 0 0 0 1]

Checks against Simscape:
    q = [0, 0, 0, 0, 0, 0]        -> X = [0, 0, 1347.5] mm
    q = [45, 45, 45, 45, 45, 45]  -> X = [517.42, 568.69, 660.48] mm

zero_pose_is_identity = False -> R is exactly what Simscape's sensor frame has
zero_pose_is_identity = True  -> R is re-defined so that R = I at q = 0
"""
import sys
import numpy as np

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def rtf(t_in, ang, ax):
    """Rigid transform: translation in inches (converted to mm), angle-axis rotation."""
    ax = np.asarray(ax, float)
    ax = ax / np.linalg.norm(ax)
    K = np.array([[0, -ax[2], ax[1]],
                  [ax[2], 0, -ax[0]],
                  [-ax[1], ax[0], 0]])
    T = np.eye(4)
    T[:3, :3] = np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * (K @ K)
    T[:3, 3] = np.asarray(t_in, float) * 25.4
    return T


def rz(a):
    """Revolute joint: rotation about the joint z axis."""
    c, s = np.cos(a), np.sin(a)
    T = np.eye(4)
    T[:3, :3] = [[c, -s, 0], [s, c, 0], [0, 0, 1]]
    return T


def rsq(order, ang_deg):
    """Rotation sequence about the follower (current) axes, e.g. 'ZXY', [90, 0, 0]."""
    R = np.eye(3)
    for ch, a in zip(order, ang_deg):
        a = np.deg2rad(a)
        c, s = np.cos(a), np.sin(a)
        Rk = {'X': [[1, 0, 0], [0, c, -s], [0, s, c]],
              'Y': [[c, 0, s], [0, 1, 0], [-s, 0, c]],
              'Z': [[c, -s, 0], [s, c, 0], [0, 0, 1]]}[ch]
        R = R @ np.array(Rk)
    T = np.eye(4)
    T[:3, :3] = R
    return T


# ---------------------------------------------------------------------------
# Model constants
# ---------------------------------------------------------------------------
_s = 0.57735026918962584      # 1/sqrt(3)
_a = 2.0943951023931953       # 120 deg (all CAD frame rotations)

# Frames from the DataFile (RigidTransform(k)): translation [in], angle, axis
B1 = rtf([0.98425196850393726, 5.6652059043882836, 15.748031496062993], _a, [_s, -_s, _s])    # a1 -> a2 (base side)
F1 = rtf([0.9842519685040052, 5.6652059043882934, 15.74803149606314], _a, [_s, -_s, _s])      # a1 -> a2 (follower side)
B2 = rtf([0.98425196850393681, 2.2244094488188995, 33.661417322834652], _a, [-_s, -_s, -_s])  # a2 -> a3
F2 = rtf([0.9842519685039619, 2.2244094488188999, 33.661417322835042], _a, [-_s, -_s, -_s])
B3 = rtf([9.4488188976377927, 0, 34.645669291338578], _a, [-_s, -_s, _s])                     # a3 -> a4
F3 = rtf([9.4488188976376986, 0, 34.645669291338962], _a, [-_s, -_s, _s])
B4 = rtf([17.519685039370085, 1.7125984251968585, 34.645669291338585], _a, [-_s, -_s, -_s])   # a4 -> a5
F4 = rtf([17.519685039370323, 1.7125984251969015, 34.645669291338642], _a, [-_s, -_s, -_s])
B5 = rtf([20.374015748031489, 0, 34.645669291338585], _a, [-_s, -_s, _s])                     # a5 -> a6

# Rotation-only Rigid Transforms added in the model (follower-axes sequences, degrees)
U0  = rsq('ZXY', [90, 0, 0])        # Rigid Transform   (before joint 1)
U1  = rsq('ZXY', [90, 0, 0])        # Rigid Transform1  (after  joint 1)
U3  = rsq('ZXZ', [90, 0, 180])      # Rigid Transform3  (before joint 2)
U2  = rsq('ZXY', [90, 0, 0])        # Rigid Transform2  (after  joint 2)
U5  = rsq('ZYZ', [-90, 180, 180])   # Rigid Transform5  (before joint 3)
U4  = rsq('ZYZ', [-90, 180, 0])     # Rigid Transform4  (after  joint 3)
U6  = rsq('XZX', [180, -90, 0])     # Rigid Transform6  (before joint 4)
U7  = rsq('XZX', [180, -90, 0])     # Rigid Transform7  (after  joint 4)
U8  = rsq('XZX', [180, 180, 0])     # Rigid Transform8  (before joint 5)
U9  = rsq('XZX', [180, 180, 0])     # Rigid Transform9  (after  joint 5)
U11 = rsq('XZX', [180, -90, 0])     # Rigid Transform11 (before joint 6)
U10 = rsq('XZX', [180, -90, 0])     # Rigid Transform10 (after  joint 6 = sensor frame)

# Pre-computed part-to-part transforms (left frame inverse * right frame)
_P2 = np.linalg.inv(F1) @ B2
_P3 = np.linalg.inv(F2) @ B3
_P4 = np.linalg.inv(F3) @ B4
_P5 = np.linalg.inv(F4) @ B5


def chain(q):
    """Frame chain of the Simscape model. q = [q1..q6] in RADIANS."""
    # Joint 3 has a -pi/2 offset in the model (Constant2 = -pi/2 added to q3)
    qj = [q[0], q[1], q[2] - np.pi / 2, q[3], q[4], q[5]]

    T = np.eye(4)                              # World / base (identity)
    T = T @ U0 @ rz(qj[0]) @ U1                # joint 1 (base -> a1)
    T = T @ B1                                 # a1 part
    T = T @ U3 @ rz(qj[1]) @ U2                # joint 2 (a1 -> a2)
    T = T @ _P2                                # a2 part
    T = T @ U5 @ rz(qj[2]) @ U4                # joint 3 (a2 -> a3)
    T = T @ _P3                                # a3 part
    T = T @ U6 @ rz(qj[3]) @ U7                # joint 4 (a3 -> a4)
    T = T @ _P4                                # a4 part
    T = T @ U8 @ rz(qj[4]) @ U9                # joint 5 (a4 -> a5)
    T = T @ _P5                                # a5 part
    T = T @ U11 @ rz(qj[5]) @ U10              # joint 6 (a5 -> a6), sensor frame
    return T


# ---------------------------------------------------------------------------
# Main function
# ---------------------------------------------------------------------------
def forward_kinematics_func(q1, q2, q3, q4, q5, q6, zero_pose_is_identity=False):
    """Returns (X, R, T_total). Angles in DEGREES, position in mm."""
    q = np.deg2rad([q1, q2, q3, q4, q5, q6])
    T_total = chain(q)
    if zero_pose_is_identity:
        T0 = chain(np.zeros(6))
        T_total[:3, :3] = T_total[:3, :3] @ T0[:3, :3].T
    R = T_total[:3, :3]
    X = T_total[:3, 3]
    return X, R, T_total


if __name__ == "__main__":
    if len(sys.argv) == 7:
        angles = [float(a) for a in sys.argv[1:7]]
    else:
        print("Enter joint angles in DEGREES:")
        angles = [float(input(f"q{i} = ")) for i in range(1, 7)]

    X, R, T = forward_kinematics_func(*angles)
    np.set_printoptions(suppress=True, precision=4)
    print("\nTransformation Matrix T (World -> end effector):")
    print(T)
    print("\nRotation Matrix R:")
    print(R)
    print("\nEnd-Effector Position (mm):")
    print(f"X = {X[0]:.3f}\nY = {X[1]:.3f}\nZ = {X[2]:.3f}")
