% Simscape(TM) Multibody(TM) version: 26.1%%%%% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData

%============= RigidTransform%
%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(13).translation = [0.0 0.0 0.0];
smiData.RigidTransform(13).angle = 0.0;
smiData.RigidTransform(13).axis = [0.0 0.0 0.0];
smiData.RigidTransform(13).ID = "";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0.98425196850393726 5.6652059043882836 15.748031496062993];  % in
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = "B[KR6 KR10 R900-2 a1-1:-:KR6 KR10 R900-2 a2-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0.9842519685040052 5.6652059043882934 15.74803149606314];  % in
smiData.RigidTransform(2).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(2).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(2).ID = "F[KR6 KR10 R900-2 a1-1:-:KR6 KR10 R900-2 a2-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0 0 0];  % in
smiData.RigidTransform(3).angle = 0;  % rad
smiData.RigidTransform(3).axis = [0 0 0];
smiData.RigidTransform(3).ID = "B[KR6 KR10 R900-2 base-1:-:KR6 KR10 R900-2 a1-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [0 0 0];  % in
smiData.RigidTransform(4).angle = 0;  % rad
smiData.RigidTransform(4).axis = [0 0 0];
smiData.RigidTransform(4).ID = "F[KR6 KR10 R900-2 base-1:-:KR6 KR10 R900-2 a1-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0.98425196850393681 2.2244094488188995 33.661417322834652];  % in
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(5).ID = "B[KR6 KR10 R900-2 a2-1:-:KR6 KR10 R900-2 a3-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [0.9842519685039619 2.2244094488188999 33.661417322835042];  % in
smiData.RigidTransform(6).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(6).axis = [-0.57735026918962562 -0.57735026918962618 -0.57735026918962562];
smiData.RigidTransform(6).ID = "F[KR6 KR10 R900-2 a2-1:-:KR6 KR10 R900-2 a3-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [9.4488188976377927 0 34.645669291338578];  % in
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = "B[KR6 KR10 R900-2 a3-1:-:KR6 KR10 R900-2 a4-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [9.4488188976376986 -9.5923269327613525e-14 34.645669291338962];  % in
smiData.RigidTransform(8).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962606 -0.57735026918962651 0.57735026918962473];
smiData.RigidTransform(8).ID = "F[KR6 KR10 R900-2 a3-1:-:KR6 KR10 R900-2 a4-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [17.519685039370085 1.7125984251968585 34.645669291338585];  % in
smiData.RigidTransform(9).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(9).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(9).ID = "B[KR6 KR10 R900-2 a4-1:-:KR6 KR10 R900-2 a5-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [17.519685039370323 1.7125984251969015 34.645669291338642];  % in
smiData.RigidTransform(10).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(10).axis = [-0.57735026918962562 -0.57735026918962651 -0.57735026918962518];
smiData.RigidTransform(10).ID = "F[KR6 KR10 R900-2 a4-1:-:KR6 KR10 R900-2 a5-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [20.374015748031489 8.7419135797256423e-15 34.645669291338585];  % in
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = "B[KR6 KR10 R900-2 a5-1:-:KR6 KR10 R900-2 a6-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [20.374015748031447 4.8672177399566863e-13 34.645669291339082];  % in
smiData.RigidTransform(12).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(12).axis = [-0.57735026918962606 -0.57735026918962595 0.57735026918962518];
smiData.RigidTransform(12).ID = "F[KR6 KR10 R900-2 a5-1:-:KR6 KR10 R900-2 a6-1]";

%%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0 0 0];  % in
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = "RootGround[KR6 KR10 R900-2 base-1]";

%============= Solid%
%%%Product of Inertia (PoI)
%Initialize the Solid structure array by filling in null values.
smiData.Solid(7).mass = 0.0;
smiData.Solid(7).CoM = [0.0 0.0 0.0];
smiData.Solid(7).MoI = [0.0 0.0 0.0];
smiData.Solid(7).PoI = [0.0 0.0 0.0];
smiData.Solid(7).color = [0.0 0.0 0.0];
smiData.Solid(7).opacity = 0.0;
smiData.Solid(7).ID = "";

%%Visual Properties - Simple
smiData.Solid(1).mass = 0.0024528522951956671;  % kg
smiData.Solid(1).CoM = [13.13546866113551 0.093353267053872771 34.642810305290986];  % in
smiData.Solid(1).MoI = [0.010291134534620432 0.016811906718016034 0.021263973212720607];  % kg*in^2
smiData.Solid(1).PoI = [5.0825780841706449e-06 3.5118019275346122e-05 -0.0011491010766046855];  % kg*in^2
smiData.Solid(1).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "KR6 KR10 R900-2 a4*:*Default";

%%Visual Properties - Simple
smiData.Solid(2).mass = 0.0039761255510690988;  % kg
smiData.Solid(2).CoM = [3.0502973980328276 -0.10796541474241671 34.099658954503496];  % in
smiData.Solid(2).MoI = [0.016035997321735346 0.044427254721918816 0.0428596957746369];  % kg*in^2
smiData.Solid(2).PoI = [-9.0144132472965075e-05 -0.0048363929290065949 -0.00066172598454408433];  % kg*in^2
smiData.Solid(2).color = [0.80000000000000004 0.80000000000000004 0.80000000000000004];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "KR6 KR10 R900-2 a3*:*Default";

%%Visual Properties - Simple
smiData.Solid(3).mass = 7.6023476856489422e-05;  % kg
smiData.Solid(3).CoM = [20.561952535184712 5.2155876399824937e-12 34.64602415408168];  % in
smiData.Solid(3).MoI = [8.4195058073777018e-05 4.489718738144089e-05 4.4891878438306282e-05];  % kg*in^2
smiData.Solid(3).PoI = [0 -6.4023373788378273e-09 0];  % kg*in^2
smiData.Solid(3).color = [0.20000000000000001 0.20000000000000001 0.20000000000000001];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "KR6 KR10 R900-2 a6*:*Default";

%%Visual Properties - Simple
smiData.Solid(4).mass = 0.00076356750668174988;  % kg
smiData.Solid(4).CoM = [17.970587627853863 -0.055991882771040072 34.64550271769231];  % in
smiData.Solid(4).MoI = [0.0013264568779890558 0.0017003051548897415 0.0019398233971048293];  % kg*in^2
smiData.Solid(4).PoI = [1.7289778455107453e-07 1.406972599139996e-07 -1.5347319565387736e-05];  % kg*in^2
smiData.Solid(4).color = [0.80000000000000004 0.80000000000000004 0.80000000000000004];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "KR6 KR10 R900-2 a5*:*Default";

%%Visual Properties - Simple
smiData.Solid(5).mass = 0.011752258340830586;  % kg
smiData.Solid(5).CoM = [-1.8195063412721033 -0.038582721117368227 4.4784858257662421];  % in
smiData.Solid(5).MoI = [0.1211596923192023 0.20759287829180462 0.18849106436758797];  % kg*in^2
smiData.Solid(5).PoI = [-6.4351517609180663e-05 -0.0054131032990234968 -0.00337109439409944];  % kg*in^2
smiData.Solid(5).color = [0.20000000000000001 0.20000000000000001 0.20000000000000001];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "KR6 KR10 R900-2 base*:*Default";

%%Visual Properties - Simple
smiData.Solid(6).mass = 0.0059769466059158283;  % kg
smiData.Solid(6).CoM = [0.31139650783610678 -0.020110599054362181 13.134836162020878];  % in
smiData.Solid(6).MoI = [0.11084527767141901 0.070808689234365271 0.083520546490917932];  % kg*in^2
smiData.Solid(6).PoI = [0.00075935134374027974 -0.0076799098851284631 0.00038740370618813713];  % kg*in^2
smiData.Solid(6).color = [0.80000000000000004 0.80000000000000004 0.80000000000000004];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "KR6 KR10 R900-2 a1*:*Default";

%%Visual Properties - Simple
smiData.Solid(7).mass = 0.0096688132242448641;  % kg
smiData.Solid(7).CoM = [0.66563164902606575 0.051882001193700872 24.043912211930479];  % in
smiData.Solid(7).MoI = [0.49289598515218891 0.45049274117179233 0.081747368853888544];  % kg*in^2
smiData.Solid(7).PoI = [-0.004274535956959198 0.0017276024731231207 -0.00016353637684065811];  % kg*in^2
smiData.Solid(7).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = "KR6 KR10 R900-2 a2*:*Default";

%============= Joint%
%%%%%%%%%%Position Target (Pos)
%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(6).Rz.Pos = 0.0;
smiData.RevoluteJoint(6).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = 5.522168750687614;  % deg
smiData.RevoluteJoint(1).ID = "[KR6 KR10 R900-2 a1-1:-:KR6 KR10 R900-2 a2-1]";

smiData.RevoluteJoint(2).Rz.Pos = 13.13778244006982;  % deg
smiData.RevoluteJoint(2).ID = "[KR6 KR10 R900-2 base-1:-:KR6 KR10 R900-2 a1-1]";

smiData.RevoluteJoint(3).Rz.Pos = -158.01468110506889;  % deg
smiData.RevoluteJoint(3).ID = "[KR6 KR10 R900-2 a2-1:-:KR6 KR10 R900-2 a3-1]";

smiData.RevoluteJoint(4).Rz.Pos = 133.20963715175773;  % deg
smiData.RevoluteJoint(4).ID = "[KR6 KR10 R900-2 a3-1:-:KR6 KR10 R900-2 a4-1]";

smiData.RevoluteJoint(5).Rz.Pos = 4.4386491433749606;  % deg
smiData.RevoluteJoint(5).ID = "[KR6 KR10 R900-2 a4-1:-:KR6 KR10 R900-2 a5-1]";

smiData.RevoluteJoint(6).Rz.Pos = 58.023380669541403;  % deg
smiData.RevoluteJoint(6).ID = "[KR6 KR10 R900-2 a5-1:-:KR6 KR10 R900-2 a6-1]";

