# kr6_gazebo - KUKA KR6 R900 in Gazebo (ROS 2 Jazzy + Gazebo Harmonic)

One robot: the KR6, with the real KUKA parts (from your STEP files) on the DH frames of forward_kinematics_func.m.

## Install (replace any older copy)
```bash
rm -rf ~/red_ws/src/kr6_gazebo ~/red_ws/build/kr6_gazebo ~/red_ws/install/kr6_gazebo
unzip -o ~/Downloads/kr6_gazebo.zip -d ~/red_ws/src/
cd ~/red_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install --packages-select kr6_gazebo
source install/setup.bash
```

## Run (terminal 1)
```bash
ros2 launch kr6_gazebo kr6_gazebo.launch.py                  # real KUKA parts
ros2 launch kr6_gazebo kr6_gazebo.launch.py use_meshes:=false # simple cylinders (fallback)
```

The arm starts fully straight, every link vertical (about 10 s after launch): q = -109.5 -180 0 0 0 -129.23 deg, end effector at z = 1367.5 mm. Use `ros2 launch kr6_gazebo kr6_gazebo.launch.py start_home:=false` to stay in the DH zero pose.

## Test cases (terminal 2; source /opt/ros/jazzy/setup.bash and ~/red_ws/install/setup.bash first)
```bash
ros2 run kr6_gazebo move_and_read.py --q 0 0 0 0 0 0 --label zeros --csv results.csv
ros2 run kr6_gazebo move_and_read.py --q <6 angles in degrees> --label random1 --csv results.csv
```
Use the SAME angles as in Simscape. Output: DH-FK vs Gazebo XYZ in mm and the error.

## Notes
* Frames: every dh_link_i is DH frame i. The end-effector frame ee_link = DH frame 6. TF reference frame: world = DH frame 0.
* q = 0 is the DH zero pose: the arm points DOWN (end effector z = -610 mm). For a normal upright picture use
  `--q -109.5 -176 84.8 -0.6 1.5 -129.2` (the CAD pose of the KUKA).
* The KUKA parts are rigidly attached to the DH joint frames. Your DH link lengths differ from the CAD by 15-40 mm,
  so the parts can show small gaps/overlaps at the shoulder/elbow while moving. The XYZ results come from the DH
  frames and are not affected.
* Gravity is off and inertias are simplified so the position controllers hold the angles. Joint limits are +-pi.
* Gains for the JointPositionController plugins are in urdf/kr6.urdf.xacro if a joint oscillates.
