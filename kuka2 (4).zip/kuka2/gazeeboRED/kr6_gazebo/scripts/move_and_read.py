#!/usr/bin/env python3
"""Command the KR6 in Gazebo to a set of joint angles, read the end-effector pose from TF,
and compare it with the DH forward kinematics (copied from forward_kinematics_func.m).

  ros2 run kr6_gazebo move_and_read.py --q 0 0 0 0 0 0 --label zeros
  ros2 run kr6_gazebo move_and_read.py --q 30 -20 40 15 -35 60 --label random1 --csv results.csv

Angles are in DEGREES (same as forward_kinematics_func.m). Positions are printed in mm.
"""
import argparse
import csv
import math
import os
import sys
import time

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.time import Time
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64
from tf2_ros import Buffer, TransformListener

JOINTS = [f'joint_{i}' for i in range(1, 7)]


# ---- DH forward kinematics: identical to dh_chain() in forward_kinematics_func.m ----------------
def _tf(theta, d, a, alpha):
    ct, st, ca, sa = math.cos(theta), math.sin(theta), math.cos(alpha), math.sin(alpha)
    return np.array([[ct, -st * ca, st * sa, a * ct],
                     [st, ct * ca, -ct * sa, a * st],
                     [0, sa, ca, d],
                     [0, 0, 0, 1.0]])


def dh_fk_mm(q_deg):
    q = np.radians(q_deg)
    L1, L2, L3, L4, L5, L6 = 378.65, 494.78, 196.26, 208.37, 73.96, 15.47
    rows = [(q[0] + math.pi / 2, L1, 0, -math.pi / 2), (q[1] + math.pi / 2, 0, L2, 0),
            (q[2] - math.pi / 2, 0, 0, -math.pi / 2), (q[3], L3 + L4, 0, math.pi / 2),
            (q[4], 0, 0, -math.pi / 2), (q[5], L6 + L5, 0, 0)]
    T = np.eye(4)
    for r in rows:
        T = T @ _tf(*r)
    return T[:3, 3]


class Runner(Node):
    def __init__(self):
        super().__init__('move_and_read', parameter_overrides=[Parameter('use_sim_time', value=True)])
        self.pubs = [self.create_publisher(Float64, f'/kr6/joint_{i}/cmd_pos', 10) for i in range(1, 7)]
        self.js = None
        self.create_subscription(JointState, '/joint_states', self._on_js, 10)
        self.buf = Buffer()
        self.listener = TransformListener(self.buf, self)

    def _on_js(self, msg):
        self.js = dict(zip(msg.name, msg.position))

    def spin_for(self, sec):
        end = time.time() + sec
        while time.time() < end:
            rclpy.spin_once(self, timeout_sec=0.02)

    def command(self, q_rad):
        for p, v in zip(self.pubs, q_rad):
            p.publish(Float64(data=float(v)))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--q', type=float, nargs=6, default=[0.0] * 6, help='six joint angles, degrees')
    ap.add_argument('--label', default='case')
    ap.add_argument('--settle', type=float, default=8.0, help='max seconds to wait for the arm to settle')
    ap.add_argument('--ref-frame', default='world')
    ap.add_argument('--ee-frame', default='ee_link')
    ap.add_argument('--csv', default='', help='append the result to this CSV file')
    a = ap.parse_args()

    rclpy.init()
    n = Runner()
    q_deg = np.array(a.q)
    q_rad = np.radians(q_deg)

    n.get_logger().info('waiting for /joint_states and TF (is the launch file running?) ...')
    t0 = time.time()
    while n.js is None and time.time() - t0 < 30:
        n.spin_for(0.2)
    if n.js is None:
        print('ERROR: no /joint_states after 30 s. Check the launch terminal and `ros2 topic list`.')
        sys.exit(1)

    n.get_logger().info(f'commanding q = {q_deg} deg')
    t0, ok_since = time.time(), None
    while time.time() - t0 < a.settle:
        n.command(q_rad)
        n.spin_for(0.05)
        err = max(abs(n.js.get(j, 1e9) - q) for j, q in zip(JOINTS, q_rad))
        if err < 0.002:
            ok_since = ok_since or time.time()
            if time.time() - ok_since > 1.0:
                break
        else:
            ok_since = None
    n.spin_for(0.5)
    err = max(abs(n.js.get(j, 1e9) - q) for j, q in zip(JOINTS, q_rad))
    if err > 0.01:
        print(f'WARNING: joints did not reach the target (max error {math.degrees(err):.2f} deg). '
              'Position is still printed, but the controller did not settle.')

    try:
        tf = n.buf.lookup_transform(a.ref_frame, a.ee_frame, Time())
    except Exception as e:  # noqa
        print(f'ERROR: TF lookup {a.ref_frame} -> {a.ee_frame} failed: {e}')
        sys.exit(1)
    t = tf.transform.translation
    g = np.array([t.x, t.y, t.z]) * 1000.0
    fk = dh_fk_mm(q_deg)
    d = g - fk

    print('\n=== %s ===' % a.label)
    print('q (deg)           :', np.round(q_deg, 3))
    print('joint readback deg:', np.round(np.degrees([n.js[j] for j in JOINTS]), 3))
    print('            X (mm)      Y (mm)      Z (mm)')
    print('DH FK     %10.3f  %10.3f  %10.3f' % tuple(fk))
    print('Gazebo    %10.3f  %10.3f  %10.3f' % tuple(g))
    print('Error     %10.3f  %10.3f  %10.3f   |e| = %.3f mm' % (*d, np.linalg.norm(d)))

    if a.csv:
        new = not os.path.exists(a.csv)
        with open(a.csv, 'a', newline='') as f:
            w = csv.writer(f)
            if new:
                w.writerow(['label', 'q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'fk_x', 'fk_y', 'fk_z',
                            'gz_x', 'gz_y', 'gz_z', 'err_x', 'err_y', 'err_z', 'err_norm'])
            w.writerow([a.label, *q_deg, *fk, *g, *d, np.linalg.norm(d)])
        print('appended to', a.csv)
    n.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
