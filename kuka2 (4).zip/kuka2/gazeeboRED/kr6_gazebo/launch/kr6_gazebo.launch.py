import os
import xacro
from ament_index_python.packages import get_package_prefix, get_package_share_directory
from launch import LaunchDescription
from launch.actions import (AppendEnvironmentVariable, DeclareLaunchArgument,
                            ExecuteProcess, IncludeLaunchDescription, OpaqueFunction, TimerAction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def launch_setup(context, *args, **kwargs):
    pkg = get_package_share_directory('kr6_gazebo')
    use_meshes = LaunchConfiguration('use_meshes').perform(context)
    headless = LaunchConfiguration('headless').perform(context).lower() == 'true'

    urdf = xacro.process_file(
        os.path.join(pkg, 'urdf', 'kr6.urdf.xacro'),
        mappings={'use_meshes': use_meshes,
                  'mesh_dir': 'file://' + os.path.join(pkg, 'meshes')}).toxml()

    world = os.path.join(pkg, 'worlds', 'kr6_empty.sdf')
    gz = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': ('-r -s ' if headless else '-r ') + world}.items())

    rsp = Node(package='robot_state_publisher', executable='robot_state_publisher',
               parameters=[{'robot_description': urdf, 'use_sim_time': True}], output='screen')
    spawn = TimerAction(period=3.0, actions=[Node(
        package='ros_gz_sim', executable='create',
        arguments=['-topic', 'robot_description', '-name', 'kr6', '-z', '0.0'], output='screen')])
    bridge = Node(package='ros_gz_bridge', executable='parameter_bridge',
                  parameters=[{'config_file': os.path.join(pkg, 'config', 'gz_bridge.yaml')}],
                  output='screen')
    actions = [gz, rsp, spawn, bridge]
    if LaunchConfiguration('start_home').perform(context).lower() == 'true':
        # Move the arm to the fully straight pose (every link vertical) once Gazebo is up. Display only:
        # the test script commands its own angles, so results are not affected.
        script = os.path.join(get_package_prefix('kr6_gazebo'), 'lib', 'kr6_gazebo', 'move_and_read.py')
        actions.append(TimerAction(period=8.0, actions=[ExecuteProcess(
            cmd=[script, '--q', '-109.5', '-180', '0', '0', '0', '-129.23',
                 '--label', 'start_home', '--settle', '8'], output='screen')]))
    return actions


def generate_launch_description():
    share_parent = os.path.dirname(get_package_share_directory('kr6_gazebo'))
    return LaunchDescription([
        DeclareLaunchArgument('use_meshes', default_value='true',
                              description='true = real KUKA KR6 parts, false = simple cylinders'),
        DeclareLaunchArgument('headless', default_value='false'),
        DeclareLaunchArgument('start_home', default_value='true',
                              description='true = start in the upright KUKA pose, false = stay in the DH zero pose'),
        AppendEnvironmentVariable('GZ_SIM_RESOURCE_PATH', share_parent),
        OpaqueFunction(function=launch_setup),
    ])
