import numpy as np

# true  -> end-effector frame is aligned with frame 0 at the zero pose (R = I)
# false -> raw DH tool frame (x axis along the last link)
ZERO_POSE_IS_IDENTITY = True


def forward_kinematics_func(q1=None, q2=None, q3=None, q4=None):
    """
    Forward kinematics of the arm (4 commanded joints, same as Gazebo).
      Input : q1..q4 in DEGREES
      Output: X       = [x, y, z] end effector position in mm, expressed in frame 0
                        (frame 0 sits on top of the base, 6.2 mm above Base_Link in Gazebo)
              R       = 3x3 rotation matrix of the end effector w.r.t. frame 0
                        (identity at q1=q2=q3=q4=0 when ZERO_POSE_IS_IDENTITY = True)
              T_total = 4x4 homogeneous transformation matrix = [R X; 0 0 0 1]
    If called with no angles, it asks for them (degrees).
    """
    if q1 is None or q2 is None or q3 is None or q4 is None:
        print("Enter joint angles in DEGREES:")
        q1 = float(input("q1 = "))
        q2 = float(input("q2 = "))
        q3 = float(input("q3 = "))
        q4 = float(input("q4 = "))

    # Degrees to radians
    q = np.array([q1, q2, q3, q4], dtype=float) * np.pi / 180

    # Total transformation from the DH table (raw DH tool frame)
    T_raw = dh_chain(q)

    X = T_raw[0:3, 3]          # position (mm), unaffected by the frame choice
    R = T_raw[0:3, 0:3]        # raw DH rotation

    if ZERO_POSE_IS_IDENTITY:
        # Orientation of the raw DH tool frame at the zero pose
        T_zero = dh_chain(np.zeros(4))
        R0 = T_zero[0:3, 0:3]
        # Re-define the tool frame so it coincides with frame 0 at the zero pose
        R = R @ R0.T

    T_total = np.eye(4)
    T_total[0:3, 0:3] = R
    T_total[0:3, 3] = X

    return X, R, T_total


def dh_chain(q):
    """Chains the DH transforms for joint angles q = [q1 q2 q3 q4] in RADIANS."""

    # Actual robot link lengths in mm
    L1 = 43.55
    L2 = 140
    L3 = 136.76    # Joint_3 -> Joint_4 (URDF: 132.9 mm)
    L4 = 30.41     # Joint_4 -> end effector along the link

    # DH parameters: [theta, d, a, alpha]
    # Zero pose = arm standing straight up (same as Gazebo), so joint 2 has a +90 deg offset.
    DH = np.array([
        [q[0] + np.pi,      L1, 0,  np.pi / 2],
        [q[1] + np.pi / 2,  0,  L2, 0],
        [q[2],              0,  L3, 0],
        [q[3],              0,  L4, 0],
    ])

    T_total = np.eye(4)
    for i in range(DH.shape[0]):
        T = transformation_func(DH[i, 0], DH[i, 1], DH[i, 2], DH[i, 3])
        T_total = T_total @ T
    return T_total


def transformation_func(theta, d, a, alpha):
    """Standard DH homogeneous transformation: Rz(theta)*Tz(d)*Tx(a)*Rx(alpha)"""
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)

    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0,        sa,       ca,      d],
        [0,         0,        0,      1],
    ])


if __name__ == "__main__":
    # Run with no angles: ask for them and print the results
    np.set_printoptions(precision=4, suppress=True)
    X, R, T_total = forward_kinematics_func()

    print("\nTransformation Matrix T (frame 0 -> end effector):")
    print(T_total)

    print("\nRotation Matrix R:")
    print(R)

    print("\nEnd-Effector Position (mm):")
    print(f"X = {X[0]:.3f}\nY = {X[1]:.3f}\nZ = {X[2]:.3f}")
    