function [X, R, T_total] = forward_kinematics_func(q1, q2, q3, q4)
% Forward kinematics of the arm (4 commanded joints, same as Gazebo).
%   Input : q1..q4 in DEGREES
%   Output: X       = [x; y; z] end effector position in mm, expressed in frame 0
%                     (frame 0 sits on top of the base, 6.2 mm above Base_Link in Gazebo)
%           R       = 3x3 rotation matrix of the end effector w.r.t. frame 0
%                     (identity at q1=q2=q3=q4=0 when zero_pose_is_identity = true)
%           T_total = 4x4 homogeneous transformation matrix = [R X; 0 0 0 1]
% If you press Run with no angles, ask for them (degrees), like the Python code

% true  -> end-effector frame is aligned with frame 0 at the zero pose (R = I)
% false -> raw DH tool frame (x axis along the last link)
zero_pose_is_identity = true;

if nargin < 4
    disp('Enter joint angles in DEGREES:');
    q1 = input('q1 = ');
    q2 = input('q2 = ');
    q3 = input('q3 = ');
    q4 = input('q4 = ');
end

% Degrees to radians
q = [q1 q2 q3 q4] * pi/180;

% Total transformation from the DH table (raw DH tool frame)
T_raw = dh_chain(q);

X = T_raw(1:3, 4);        % position (mm), unaffected by the frame choice
R = T_raw(1:3, 1:3);      % raw DH rotation

if zero_pose_is_identity
    % Orientation of the raw DH tool frame at the zero pose
    T_zero = dh_chain([0 0 0 0]);
    R0 = T_zero(1:3, 1:3);
    % Re-define the tool frame so it coincides with frame 0 at the zero pose
    R = R * R0.';
end

T_total = [R, X; 0 0 0 1];

% Run pressed with no output requested: print the results
if nargout == 0
    fprintf('\nTransformation Matrix T (frame 0 -> end effector):\n');
    disp(T_total);

    fprintf('Rotation Matrix R:\n');
    disp(R);

    fprintf('End-Effector Position (mm):\n');
    fprintf('X = %.3f\nY = %.3f\nZ = %.3f\n', X);

    clear X R T_total
end

end

% ------------------------------------------------------------------
function T_total = dh_chain(q)
% Chains the DH transforms for joint angles q = [q1 q2 q3 q4] in RADIANS.

    % Actual robot link lengths in mm
    L1 = 43.55;
    L2 = 140;
    L3 = 136.76;    % Joint_3 -> Joint_4 (URDF: 132.9 mm)
    L4 = 30.41;     % Joint_4 -> end effector along the link

    % DH parameters: [theta, d, a, alpha]
    % Zero pose = arm standing straight up (same as Gazebo), so joint 2 has a +90 deg offset.
    DH = [ q(1)+pi,      L1, 0,  pi/2;
           q(2)+pi/2,    0,  L2, 0;
           q(3),         0,  L3, 0;
           q(4),         0,  L4, 0 ];

    T_total = eye(4);
    for i = 1:size(DH, 1)
        T = transformation_func(DH(i,1), DH(i,2), DH(i,3), DH(i,4));
        T_total = T_total * T;
    end
end

function T = transformation_func(theta, d, a, alpha)
% Standard DH homogeneous transformation: Rz(theta)*Tz(d)*Tx(a)*Rx(alpha)
    ct = cos(theta);  st = sin(theta);
    ca = cos(alpha);  sa = sin(alpha);

    T = [ ct, -st*ca,  st*sa, a*ct;
          st,  ct*ca, -ct*sa, a*st;
           0,     sa,     ca,    d;
           0,      0,      0,    1 ];
end
