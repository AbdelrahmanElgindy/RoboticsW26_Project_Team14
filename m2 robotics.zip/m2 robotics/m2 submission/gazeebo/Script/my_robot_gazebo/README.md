# my_robot_gazebo (ROS 2 Jazzy + Gazebo Harmonic)

Spawns a 4-DOF URDF arm in Gazebo Sim. No scaling is applied — meshes are used as exported.
The four commandable joints are `Joint_1` … `Joint_4`; a fifth joint is welded — see
[Locked joint](#locked-joint).

Ported from ROS 1 Noetic + Gazebo Classic. The ROS-facing interface is unchanged:

| Topic | Type | Direction |
|---|---|---|
| `/Joint_1/command` … `/Joint_4/command` | `std_msgs/Float64` | in — target joint angle (rad) |
| `/joint_states` | `sensor_msgs/JointState` | out — actual joint state from Gazebo |
| `/end_effector_pose` | `geometry_msgs/PoseStamped` | out — `EE_frame` in `world` |

## 1) Build

```bash
mkdir -p ~/ros2_ws/src
cp -r /path/to/my_robot_gazebo ~/ros2_ws/src/
cd ~/ros2_ws
colcon build --packages-select my_robot_gazebo --symlink-install
source install/setup.bash
```

## 2) Spawn in Gazebo

```bash
ros2 launch my_robot_gazebo spawn_gazebo.launch.py
```

Arguments: `model`, `world`, `gui` (`false` = headless), `rviz`, `x`, `y`, `z`, `Y`.

`x/y/z/Y` set where the base is **welded to the world**, not a free spawn pose — they are
passed into the xacro, so Gazebo and TF agree on where the robot is.

```bash
ros2 launch my_robot_gazebo spawn_gazebo.launch.py x:=1.0 y:=2.0 z:=0.2 Y:=1.57
ros2 launch my_robot_gazebo spawn_gazebo.launch.py gui:=false rviz:=true
```

Move a joint:

```bash
ros2 topic pub -1 /Joint_1/command std_msgs/msg/Float64 "{data: 1.57}"
```

> If a single `-1` publish seems to do nothing, it is the usual ROS 2 discovery race:
> `ros2 topic pub` can exit before its publisher matches the driver. Use
> `ros2 topic pub -r 10 /Joint_1/command ...` for a second, or just publish again.

## 3) Quick RViz check (no Gazebo)

```bash
ros2 launch my_robot_gazebo view_model.launch.py
```

## Locked joint

The arm has four controllable degrees of freedom, `Joint_1` … `Joint_4`. The joint that
used to sit between `Joint_3` and the wrist is **welded**: it is a `fixed` joint named
**`Arm_3_lock`** (`Arm_2` → `Arm_3`), locked at **0 rad**, its original zero position, so
the home geometry is unchanged from the 5-DOF version.

Joint numbering was closed up so the commandable joints run 1..4 with no gap:

| 5-DOF name | now |
|---|---|
| `Joint_1` … `Joint_3` | unchanged |
| `Joint_4` (`Arm_2` → `Arm_3`) | **`Arm_3_lock`**, `type="fixed"` |
| `Joint_5` (wrist, `Arm_3` → `Gripper`) | **`Joint_4`**, still `revolute` |

The weld is named `Arm_3_lock` rather than `Joint_4` both to free that name for the wrist
and to follow the `EE_frame_lock` convention for a welded joint.

**The welded joint does not appear in `/joint_states`** — sdformat lumps a fixed joint away
entirely, so it is not a joint in the spawned model at all. `/joint_states` carries
`world_to_base_footprint, Joint_1, Joint_2, Joint_3, Joint_4`. (The weld to the world
survives as a joint because it attaches to a separate model; `Arm_3_lock` does not.) The
`Arm_2` → `Arm_3` transform moves from `/tf` to `/tf_static`. `Arm_3` remains a TF frame
and the full `world` → `EE_frame` chain is intact.

Likewise `Arm_3` is no longer a *link* in the generated SDF — sdformat lumps it into
`Arm_2`. That is why it carries no `<gazebo reference>` flags. Check with
`gz sdf -p <generated>.urdf | grep "<link name="`.

### Restoring the 5th DOF

| File | Edit |
|---|---|
| `urdf/robot.urdf.xacro` | rename the wrist `Joint_4` back to `Joint_5`; rename `Arm_3_lock` back to `Joint_4` with `type="revolute"` plus its `<axis>`, `<limit>`, `<dynamics>`; re-add `<xacro:link_flags link="Arm_3"/>` |
| `urdf/robot.gazebo.xacro` | drive `Joint_4` and `Joint_5` |
| `urdf/robot.ros2_control.xacro` | claim `Joint_4` and `Joint_5` |
| `config/gz_bridge.yaml` | `cmd_pos` mappings for `Joint_4` and `Joint_5` |
| `config/controllers.yaml`, `launch/spawn_gazebo.launch.py`, `scripts/kinematic_joint_driver.py` | five names in the joint lists |

To lock `Arm_3_lock` at a **different** angle instead, bake the rotation into its
`<origin>` rpy. You cannot just change yaw: the axis was `0 0 -1` (the child frame's −z),
so the locked pose is `R(origin_rpy) · Rz(−θ)`, which is not a per-axis rpy edit.

## Control backends

**A. gz plugins (default).** `urdf/robot.gazebo.xacro` adds one
`gz::sim::systems::JointPositionController` per joint; `config/gz_bridge.yaml` bridges
the commands and the joint states. Nothing extra to install.

**B. ros2_control (opt-in).**

```bash
sudo apt install ros-jazzy-gz-ros2-control ros-jazzy-ros2-controllers
ros2 launch my_robot_gazebo spawn_gazebo_ros2_control.launch.py
```

Commands go to `/arm_position_controller/commands` (`std_msgs/Float64MultiArray`, 4 values,
ordered `Joint_1` … `Joint_4`)
instead of the per-joint topics. See `config/controllers.yaml`. The optional dependencies
are listed commented-out in `package.xml`; uncomment them if you standardise on this path.

## What changed in the port

| ROS 1 / Gazebo Classic | ROS 2 Jazzy / Gazebo Harmonic |
|---|---|
| catkin, `package.xml` format 2 | `ament_cmake`, format 3 |
| `.launch` XML | `.launch.py` |
| `gazebo_ros` `empty_world.launch` | `ros_gz_sim` `gz_sim.launch.py` |
| `gazebo_ros/spawn_model -param … -urdf` | `ros_gz_sim create -topic /robot_description` |
| `/gazebo/set_model_configuration` (joint teleport) | `JointPositionController` plugins + `ros_gz_bridge` |
| `/gazebo/get_link_state` for EE pose | TF lookup `world → EE_frame` |
| `<transmission>` + `PositionJointInterface` | gz plugins, or `<ros2_control>` in backend B |
| `urdf/robot.urdf` | `urdf/robot.urdf.xacro` (+ two backend includes) |
| `rospy`, `rospkg` | `rclpy`, `ament_index_python` |

The base is welded to the world by a `<link name="world"/>` plus a fixed joint in
`robot.urdf.xacro`. This is required, not cosmetic: the ROS 1 driver *teleported* joints, so
a free-floating base never felt a reaction force, but a real position controller does. In a
zero-gravity world with no friction there is nothing to resist it, so without the weld the
first joint command sends the whole robot tumbling away. Because `robot_state_publisher`
now owns the `world -> base_footprint` transform, the launch files no longer run a
`static_transform_publisher` for it.

Also fixed along the way: materials were all `name=""` (rejected by urdfdom/sdformat in
Jazzy) and now have real names; `EE_frame_lock` was a revolute joint locked to zero range
and is now `fixed`; ODE-only `<cfm>/<erp>` tuning and link-scope `<collide_bitmask>` were
dropped as inert under DART/sdformat; the world's `<ode>` solver block went with them, and
`ground_plane`/`sun` are inlined so startup needs no Fuel download.

`scripts/ee_pose_from_gazebo.py` became `scripts/ee_pose_publisher.py`: the pose now comes
from TF rather than the simulator, so it works under both backends and under
`view_model.launch.py` with no simulator at all. Its `link_name` parameter became
`target_frame` (the `my_robot::` Gazebo scoping prefix has no meaning on TF).

### Behavioural difference worth knowing

The ROS 1 driver *teleported* joints — instantaneous and exact. `JointPositionController`
with `use_velocity_commands` *converges* over a few control cycles instead. In this
zero-gravity world it settles quickly and lands on the target exactly, but it is not a
bit-identical replacement. Gazebo Harmonic has no joint-teleport primitive. `p_gain` in
`urdf/robot.gazebo.xacro` (default `10.0`) is the knob if you want it snappier.

## Troubleshooting

- **The base sits in / under the ground.** `Base_Link.STL` is modelled about its mounting
  face, not its underside: in the mesh frame it spans `z = -0.0438 .. +0.0062`. So
  `base_footprint_to_Base_Link` lifts `Base_Link` by `base_link_lift` (`0.0438`) in
  `urdf/robot.urdf.xacro`, which puts the bottom of the base exactly on `z=0` and keeps
  `base_footprint` meaning what REP 120 says it means. **That constant is tied to the
  mesh** — re-export `Base_Link.STL` and you must re-measure it, or the base will sink or
  float again. `z:=<h>` then raises the whole arm `h` above the ground as you would expect.
- **Robot spawns with invisible / white links.** Gazebo could not resolve
  `package://my_robot_gazebo/meshes/...`. The launch files set `GZ_SIM_RESOURCE_PATH` to the
  parent of the package share directory; if you spawn the model by hand, set it yourself.
- **`/joint_states` is silent.** `config/gz_bridge.yaml` hardcodes the world name (`stable`)
  and model name (`my_robot`) in the gz topic. Renaming either requires updating that file.
- **Joint commands ignored.** The gz plugin listens on `.../<joint>/0/cmd_pos`. That `0` is
  the joint index and cannot be named from ROS (a ROS 2 topic token must not start with a
  digit), so the bridge maps `.../<joint>/cmd_pos` onto it. gz-sim 8.15 ignores the plugin's
  `<topic>` element, so the remap is done in the bridge, not the URDF.
- **Meshes not showing in RViz.** RViz2 reads the model from the `/robot_description`
  *topic*, not a parameter. Keep `robot_state_publisher` running.
- **The robot flies off / drifts when you command a joint.** The base is not welded. Check
  the spawned model really has the weld:
  `gz topic -e -t /world/stable/model/my_robot/joint_state -n 1 | grep world_to_base`
  If it is missing, a **stale `robot_state_publisher` from an earlier run** is very likely
  still publishing an old `/robot_description`, and `create -topic` spawned that instead.
  Two publishers on that topic is always a bug. Clean up with:
  `pkill -f robot_state_publisher; pkill -f 'gz sim'; ros2 daemon stop`

## Regenerating the plain URDF / model SDF

```bash
xacro urdf/robot.urdf.xacro > robot.urdf          # plain URDF
gz sdf -p robot.urdf > models/my_robot/model.sdf  # real SDF (replaces the placeholder box)
```
