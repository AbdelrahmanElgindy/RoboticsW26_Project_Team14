#!/usr/bin/env python3
"""Publish the end-effector pose as a PoseStamped.

Replaces ee_pose_from_gazebo.py, which polled /gazebo/get_link_state -- a service
that does not exist in Gazebo Harmonic.

The pose is resolved from TF instead of from the simulator. The arm is a rigid
chain, so the world -> EE_frame transform published by robot_state_publisher is
exact, and this node then works identically under both control backends and under
view_model.launch.py with no simulator running at all.
"""
import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from tf2_ros import Buffer, TransformException, TransformListener


class EEPosePublisher(Node):

    def __init__(self):
        super().__init__('ee_pose_publisher')

        # target_frame replaces the old `link_name` param: the Gazebo scoping
        # prefix ("my_robot::EE_frame") has no meaning on TF.
        self.declare_parameter('target_frame', 'EE_frame')
        self.declare_parameter('reference_frame', 'world')
        self.declare_parameter('topic', 'end_effector_pose')
        self.declare_parameter('rate', 30.0)

        self.target_frame = self.get_parameter('target_frame').value
        self.reference_frame = self.get_parameter('reference_frame').value
        topic = self.get_parameter('topic').value
        rate = float(self.get_parameter('rate').value)

        self.buffer = Buffer()
        self.listener = TransformListener(self.buffer, self)
        self.pub = self.create_publisher(PoseStamped, topic, 10)

        self.create_timer(1.0 / rate, self._on_timer)
        self.get_logger().info(
            f'Publishing {self.reference_frame} -> {self.target_frame} on {topic}')

    def _on_timer(self):
        try:
            tf = self.buffer.lookup_transform(
                self.reference_frame, self.target_frame, rclpy.time.Time())
        except TransformException as exc:
            self.get_logger().warn(f'TF lookup failed: {exc}', throttle_duration_sec=2.0)
            return

        msg = PoseStamped()
        msg.header = tf.header
        msg.pose.position.x = tf.transform.translation.x
        msg.pose.position.y = tf.transform.translation.y
        msg.pose.position.z = tf.transform.translation.z
        msg.pose.orientation = tf.transform.rotation
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = EEPosePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
