#!/usr/bin/env python3
"""Relay per-joint position commands into Gazebo Sim.

The ROS 1 version called /gazebo/set_model_configuration to teleport the joints.
That service does not exist in Gazebo Harmonic and has no equivalent, so the
sink changed: commands are republished to the bridged gz command topics, where
the JointPositionController plugins (urdf/robot.gazebo.xacro) pick them up.

Everything else is carried over -- the per-joint Float64 subscriptions, the
epsilon dead-band, and the fixed-rate send loop.
"""
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64

# 4-DOF arm: the fifth joint is welded (Arm_3_lock in urdf/robot.urdf.xacro) and
# is not commandable. The launch files pass this same list via joint_names.
DEFAULT_JOINTS = ['Joint_1', 'Joint_2', 'Joint_3', 'Joint_4']

# ROS-side command topic suffix. The gz plugin actually listens on
# ".../<joint_index>/cmd_pos", but a ROS 2 topic token may not start with a
# number, so the index is dropped here and config/gz_bridge.yaml maps this name
# onto the indexed gz one.
CMD_SUFFIX = '/cmd_pos'


def almost_equal(a, b, eps):
    if math.isnan(a) or math.isnan(b):
        return False
    return abs(a - b) <= eps


class KinematicJointDriver(Node):

    def __init__(self):
        super().__init__('kinematic_joint_driver')

        self.declare_parameter('model_name', 'my_robot')
        self.declare_parameter('rate_hz', 30.0)
        self.declare_parameter('epsilon', 1e-4)
        # The gz JointStatePublisher (bridged to /joint_states) is the authoritative
        # source of actual sim state, so this defaults off. Turn it on to drive TF
        # from commanded values when running without Gazebo.
        self.declare_parameter('publish_joint_states', False)
        self.declare_parameter('command_topic_prefix', '/model/my_robot/joint/')
        self.declare_parameter('joint_names', DEFAULT_JOINTS)
        # The ROS 1 driver called a service, which could not be silently dropped.
        # A relayed topic can be: anything published before the bridge has matched
        # goes nowhere, and the epsilon dead-band then suppresses every resend
        # because the value has not changed. Re-sending each target at least this
        # often closes that window. 0 disables it (pure send-on-change).
        self.declare_parameter('keepalive_sec', 1.0)

        self.model_name = self.get_parameter('model_name').value
        rate_hz = float(self.get_parameter('rate_hz').value)
        self.epsilon = float(self.get_parameter('epsilon').value)
        publish_js = bool(self.get_parameter('publish_joint_states').value)
        prefix = self.get_parameter('command_topic_prefix').value

        self.joint_names = list(self.get_parameter('joint_names').value)
        if not self.joint_names:
            self.get_logger().fatal('joint_names is empty; nothing to drive.')
            raise SystemExit(1)

        self.keepalive_sec = float(self.get_parameter('keepalive_sec').value)

        self.values = [0.0] * len(self.joint_names)
        self.last_sent = [float('nan')] * len(self.joint_names)
        self.last_sent_at = [0.0] * len(self.joint_names)
        self.had_any_msg = False

        self._subs = []
        self._cmd_pubs = []
        for idx, jname in enumerate(self.joint_names):
            # ROS 2 has no nested-dict parameters; the joint -> input-topic mapping
            # is declared as dotted keys, e.g. joint_topic_map.Joint_1: /Joint_1/command
            self.declare_parameter(f'joint_topic_map.{jname}', f'/{jname}/command')
            in_topic = self.get_parameter(f'joint_topic_map.{jname}').value
            out_topic = f'{prefix}{jname}{CMD_SUFFIX}'

            self._subs.append(
                self.create_subscription(Float64, in_topic, self._make_cb(idx), 1))
            self._cmd_pubs.append(self.create_publisher(Float64, out_topic, 1))
            self.get_logger().info(f'{jname}:  {in_topic}  ->  {out_topic}')

        self.pub_js = self.create_publisher(JointState, 'joint_states', 10) if publish_js else None

        self.create_timer(1.0 / rate_hz, self._on_timer)
        self.get_logger().info(
            f"Kinematic driver ready for model '{self.model_name}' "
            f'({len(self.joint_names)} joints).')

    def _make_cb(self, idx):
        def _cb(msg):
            self.values[idx] = float(msg.data)
            self.had_any_msg = True
        return _cb

    def _on_timer(self):
        if not self.had_any_msg:
            return

        now = self.get_clock().now().nanoseconds * 1e-9
        for i, v in enumerate(self.values):
            changed = not almost_equal(v, self.last_sent[i], self.epsilon)
            stale = (self.keepalive_sec > 0.0
                     and now - self.last_sent_at[i] >= self.keepalive_sec)
            if changed or stale:
                self._cmd_pubs[i].publish(Float64(data=v))
                self.last_sent[i] = v
                self.last_sent_at[i] = now

        if self.pub_js is not None:
            msg = JointState()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.name = self.joint_names
            msg.position = list(self.values)
            self.pub_js.publish(msg)


def main():
    rclpy.init()
    node = KinematicJointDriver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
