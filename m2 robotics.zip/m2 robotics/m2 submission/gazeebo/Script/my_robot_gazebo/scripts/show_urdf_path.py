#!/usr/bin/env python3
import os

from ament_index_python.packages import get_package_share_directory

if __name__ == "__main__":
    p = get_package_share_directory('my_robot_gazebo')
    print("my_robot_gazebo share path:", p)
    print("Xacro default path:", os.path.join(p, 'urdf', 'robot.urdf.xacro'))
