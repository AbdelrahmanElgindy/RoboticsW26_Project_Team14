"""Spawn the arm in Gazebo Sim (Harmonic) -- control backend A, gz plugins.

ROS interface (4-DOF arm; the fifth joint is welded as Arm_3_lock):
    /Joint_1/command ... /Joint_4/command   std_msgs/Float64   (input)
    /joint_states                           sensor_msgs/JointState
    /end_effector_pose                      geometry_msgs/PoseStamped
"""
import os
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

PKG = 'my_robot_gazebo'
MODEL_NAME = 'my_robot'


def generate_launch_description():
    pkg_share = get_package_share_directory(PKG)
    ros_gz_sim_share = get_package_share_directory('ros_gz_sim')

    default_model = os.path.join(pkg_share, 'urdf', 'robot.urdf.xacro')
    default_world = os.path.join(pkg_share, 'worlds', 'stable.world')
    bridge_config = os.path.join(pkg_share, 'config', 'gz_bridge.yaml')
    rviz_config = os.path.join(pkg_share, 'rviz', 'model_view.rviz')

    model = LaunchConfiguration('model')
    world = LaunchConfiguration('world')
    x, y, z, yaw = (LaunchConfiguration(n) for n in ('x', 'y', 'z', 'Y'))

    args = [
        DeclareLaunchArgument('model', default_value=default_model,
                              description='Path to the robot xacro/urdf.'),
        DeclareLaunchArgument('world', default_value=default_world,
                              description='Path to the SDF world.'),
        DeclareLaunchArgument('gui', default_value='true',
                              description='Run the Gazebo GUI (false = headless server).'),
        DeclareLaunchArgument('rviz', default_value='false',
                              description='Also open RViz2.'),
        DeclareLaunchArgument('x', default_value='0.0'),
        DeclareLaunchArgument('y', default_value='0.0'),
        DeclareLaunchArgument('z', default_value='0.0'),
        DeclareLaunchArgument('Y', default_value='0.0', description='Spawn yaw (rad).'),
    ]

    # Gazebo cannot resolve package://my_robot_gazebo/meshes/... on its own.
    # Point it at the parent of the share directory (so package:// resolves) and at
    # models/. Without this the robot spawns with invisible links.
    gz_resource_path = SetEnvironmentVariable(
        'GZ_SIM_RESOURCE_PATH',
        os.pathsep.join([
            str(Path(pkg_share).parent),
            os.path.join(pkg_share, 'models'),
            os.environ.get('GZ_SIM_RESOURCE_PATH', ''),
        ]).rstrip(os.pathsep),
    )

    # gui:=false -> "-s" runs the server only (headless).
    headless_flag = PythonExpression(
        ["'' if '", LaunchConfiguration('gui'), "'.lower() == 'true' else '-s '"])

    gz_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ros_gz_sim_share, 'launch', 'gz_sim.launch.py')),
        launch_arguments={
            'gz_args': [headless_flag, '-r -v4 ', world],
            'on_exit_shutdown': 'true',
        }.items(),
    )

    # x/y/z/Y set the world weld in the URDF, not the spawn pose: the base is
    # welded to the world frame, so the mount pose has to live in the model for
    # Gazebo and TF to agree on where the robot is.
    robot_description = ParameterValue(
        Command(['xacro ', model, ' control_backend:=gz_plugin',
                 ' base_x:=', x, ' base_y:=', y, ' base_z:=', z,
                 ' base_yaw:=', yaw]),
        value_type=str)

    # Publishes /robot_description transient-local, which `create -topic` consumes.
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description,
                     'publish_frequency': 50.0,
                     'use_sim_time': True}],
    )

    # ROS 2 equivalent of gazebo_ros/spawn_model -param robot_description -urdf.
    # There is no -J flag; initial joint positions come from <initial_position>
    # in the JointPositionController plugins.
    spawn = Node(
        package='ros_gz_sim',
        executable='create',
        name='spawn_urdf',
        output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=['-topic', '/robot_description', '-name', MODEL_NAME],
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='gz_bridge',
        output='screen',
        parameters=[{'config_file': bridge_config, 'use_sim_time': True}],
    )

    joint_driver = Node(
        package=PKG,
        executable='kinematic_joint_driver.py',
        name='kinematic_joint_driver',
        output='screen',
        parameters=[{
            'model_name': MODEL_NAME,
            'rate_hz': 30.0,
            'epsilon': 0.0005,
            'publish_joint_states': False,
            'command_topic_prefix': f'/model/{MODEL_NAME}/joint/',
            # 4 DOF: the welded joint is Arm_3_lock and is not commandable.
            'joint_names': ['Joint_1', 'Joint_2', 'Joint_3', 'Joint_4'],
            # map each joint to its input topic
            'joint_topic_map.Joint_1': '/Joint_1/command',
            'joint_topic_map.Joint_2': '/Joint_2/command',
            'joint_topic_map.Joint_3': '/Joint_3/command',
            'joint_topic_map.Joint_4': '/Joint_4/command',
            'use_sim_time': True,
        }],
    )

    ee_pose = Node(
        package=PKG,
        executable='ee_pose_publisher.py',
        name='ee_pose_publisher',
        output='screen',
        parameters=[{
            'target_frame': 'EE_frame',
            'reference_frame': 'world',
            'topic': 'end_effector_pose',
            'rate': 30.0,
            'use_sim_time': True,
        }],
    )

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': True}],
        condition=IfCondition(LaunchConfiguration('rviz')),
    )

    return LaunchDescription(args + [
        gz_resource_path,
        gz_sim,
        robot_state_publisher,
        spawn,
        bridge,
        joint_driver,
        ee_pose,
        rviz,
    ])
