"""Spawn the arm in Gazebo Sim -- control backend B, ros2_control.

Requires packages that are NOT installed by default:
    sudo apt install ros-jazzy-gz-ros2-control ros-jazzy-ros2-controllers

Command interface differs from the default backend:
    /arm_position_controller/commands   std_msgs/Float64MultiArray  (4 values,
                                        ordered Joint_1 .. Joint_4)

gz_ros2_control publishes /joint_states itself, so only /clock is bridged.
"""
import os
from pathlib import Path

from ament_index_python.packages import PackageNotFoundError, get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription, LogInfo,
                            RegisterEventHandler, SetEnvironmentVariable, Shutdown)
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

PKG = 'my_robot_gazebo'
MODEL_NAME = 'my_robot'

APT_HINT = ('ros2_control backend requires packages that are not installed. Run:\n'
            '    sudo apt install ros-jazzy-gz-ros2-control ros-jazzy-ros2-controllers\n'
            'Or use the default backend: ros2 launch my_robot_gazebo spawn_gazebo.launch.py')


def generate_launch_description():
    pkg_share = get_package_share_directory(PKG)

    # Fail loudly and usefully rather than with an opaque "executable not found".
    for required in ('controller_manager', 'gz_ros2_control'):
        try:
            get_package_share_directory(required)
        except PackageNotFoundError:
            return LaunchDescription([
                LogInfo(msg=f"[my_robot_gazebo] missing package '{required}'.\n{APT_HINT}"),
                Shutdown(reason=f'missing {required}'),
            ])

    ros_gz_sim_share = get_package_share_directory('ros_gz_sim')

    default_model = os.path.join(pkg_share, 'urdf', 'robot.urdf.xacro')
    default_world = os.path.join(pkg_share, 'worlds', 'stable.world')

    model = LaunchConfiguration('model')
    world = LaunchConfiguration('world')

    gz_resource_path = SetEnvironmentVariable(
        'GZ_SIM_RESOURCE_PATH',
        os.pathsep.join([
            str(Path(pkg_share).parent),
            os.path.join(pkg_share, 'models'),
            os.environ.get('GZ_SIM_RESOURCE_PATH', ''),
        ]).rstrip(os.pathsep),
    )

    gz_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ros_gz_sim_share, 'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': ['-r -v4 ', world],
                          'on_exit_shutdown': 'true'}.items(),
    )

    robot_description = ParameterValue(
        Command(['xacro ', model, ' control_backend:=ros2_control']), value_type=str)

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description,
                     'publish_frequency': 50.0,
                     'use_sim_time': True}],
    )

    spawn = Node(
        package='ros_gz_sim',
        executable='create',
        name='spawn_urdf',
        output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=['-topic', '/robot_description', '-name', MODEL_NAME],
    )

    clock_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='clock_bridge',
        output='screen',
        arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
    )

    ee_pose = Node(
        package=PKG,
        executable='ee_pose_publisher.py',
        name='ee_pose_publisher',
        output='screen',
        parameters=[{'target_frame': 'EE_frame',
                     'reference_frame': 'world',
                     'topic': 'end_effector_pose',
                     'rate': 30.0,
                     'use_sim_time': True}],
    )

    jsb_spawner = Node(
        package='controller_manager', executable='spawner',
        arguments=['joint_state_broadcaster'], output='screen',
    )
    arm_spawner = Node(
        package='controller_manager', executable='spawner',
        arguments=['arm_position_controller'], output='screen',
    )

    return LaunchDescription([
        DeclareLaunchArgument('model', default_value=default_model),
        DeclareLaunchArgument('world', default_value=default_world),

        gz_resource_path,
        gz_sim,
        robot_state_publisher,
        spawn,
        clock_bridge,
        ee_pose,

        # The controller_manager only exists once the model is in the world.
        RegisterEventHandler(OnProcessExit(target_action=spawn,
                                           on_exit=[jsb_spawner])),
        RegisterEventHandler(OnProcessExit(target_action=jsb_spawner,
                                           on_exit=[arm_spawner])),
    ])
