"""Quick RViz2 check of the model -- no Gazebo.

Joint sliders from joint_state_publisher_gui drive /joint_states, which
robot_state_publisher turns into TF.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

PKG = 'my_robot_gazebo'


def generate_launch_description():
    pkg_share = get_package_share_directory(PKG)
    default_model = os.path.join(pkg_share, 'urdf', 'robot.urdf.xacro')
    rviz_config = os.path.join(pkg_share, 'rviz', 'model_view.rviz')

    model = LaunchConfiguration('model')

    robot_description = ParameterValue(
        Command(['xacro ', model, ' control_backend:=gz_plugin']), value_type=str)

    return LaunchDescription([
        DeclareLaunchArgument('model', default_value=default_model,
                              description='Path to the robot xacro/urdf.'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_description,
                         'publish_frequency': 50.0,
                         'use_sim_time': False}],
        ),

        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            output='screen',
        ),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', rviz_config],
        ),
    ])
